<footer class="main-footer">
    <div class="footer-left">
      <?=htmlspecialchars(footer_text())?>
    </div>
</footer>